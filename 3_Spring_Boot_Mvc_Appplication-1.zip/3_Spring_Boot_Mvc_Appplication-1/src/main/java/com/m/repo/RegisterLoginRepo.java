package com.m.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.m.model.RegisterLogin;

@Repository
public interface RegisterLoginRepo extends JpaRepository<RegisterLogin, Integer> {
	
    public RegisterLogin findByEmail(String email);
	
    public RegisterLogin findByNumber(Long phoneNumber);
	
	public Optional<RegisterLogin> findByEmailAndPassword(String email, String password);

}
