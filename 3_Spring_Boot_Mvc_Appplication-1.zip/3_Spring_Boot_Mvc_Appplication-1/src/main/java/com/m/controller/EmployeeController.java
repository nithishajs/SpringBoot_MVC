package com.m.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.m.model.Employee;
import com.m.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	EmployeeService service;
	
	@GetMapping("/add")
	public String addForm(Model m) {
		Employee emp = new Employee();
		m.addAttribute("employee", emp);
		return "Add_Employee";
	}
	
	@PostMapping("/adding")
	public String add(@ModelAttribute("emp") Employee emp, RedirectAttributes m) {
		if(service.addEmployee(emp)) {
			m.addFlashAttribute("error", "Employee Added Sucessfully!");
			return "redirect:/list";
		}else {
			return "redirect:/add";
		}
	
	
	}
	
	@GetMapping("/list")
	public String list(Model m) {
		return findPaginated(1, m);
	}
	

	@GetMapping("/{id}")
	public String view(@PathVariable int id, Model m) {
		Employee emp = service.viewEmployee(id);
		m.addAttribute("employee", emp);
		return "Edit_Employee";
	}
	
	@PostMapping("/{id}")
	public String update(@PathVariable int id, @ModelAttribute Employee emp, Model m, RedirectAttributes m1) {
		emp.setId(id);
		m.addAttribute("id", id);
		if(service.updateEmployee(emp)) {
			m1.addFlashAttribute("error", "Employee Updated Sucessfully!");
		    return "redirect:/list";
		}else {
			m1.addFlashAttribute("error", "Employee Not Found!");
		    return "redirect:/{id}";
		}
	}
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable int id, RedirectAttributes m) {
		if(service.deleteEmployee(id)) {
			m.addFlashAttribute("error", "Employee Deleted Sucessfully!");
			return "redirect:/list";
		}else {
			m.addFlashAttribute("error", "Employee Not Found!");
			return "redirect:/list";
		}
		
	}
	
	@GetMapping("/page/{pageNo}")
	public String findPaginated(@PathVariable(value = "pageNo") int pageNo, Model model) {
	    int pageSize = 5;

	    Page < Employee > page = service.findPaginated(pageNo, pageSize);
	    List < Employee > listEmployees = page.getContent();

	    model.addAttribute("currentPage", pageNo);
	    model.addAttribute("totalPages", page.getTotalPages());
	    model.addAttribute("totalItems", page.getTotalElements());
	    model.addAttribute("employee", listEmployees);
	    return "List_Employee";
	}

}
