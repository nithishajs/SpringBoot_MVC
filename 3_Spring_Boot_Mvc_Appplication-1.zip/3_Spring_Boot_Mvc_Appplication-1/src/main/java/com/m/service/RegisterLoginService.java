package com.m.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.m.exception.NotFound;
import com.m.model.RegisterLogin;
import com.m.repo.RegisterLoginRepo;

@Service
public class RegisterLoginService {
	
	@Autowired
	RegisterLoginRepo repo;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	public boolean register(RegisterLogin pr){
		
	RegisterLogin checkEmail = repo.findByEmail(pr.getEmail());
    RegisterLogin checkNumber = repo.findByNumber(pr.getNumber());
		
		if(checkEmail!=null) 
			throw new NotFound("Email already exist");
		else {
			if(checkNumber!=null) {
				throw new NotFound("Phone number already exist");
			}else {
				String encodedPassword = this.passwordEncoder.encode(pr.getPassword());
				pr.setPassword(encodedPassword);
				repo.save(pr);
				return true;
			}
			
		}
		

		
	}
	
	public RegisterLogin login(RegisterLogin pr){
	
	RegisterLogin pl = repo.findByEmail(pr.getEmail());
	
	if (pl != null) {
		
		String password = pr.getPassword();
		String encodedPassword = pl.getPassword();
		Boolean isPwdRight = passwordEncoder.matches(password, encodedPassword);
		
		if(isPwdRight) {
			Optional <RegisterLogin> checkCredentials = repo.findByEmailAndPassword(pr.getEmail(), encodedPassword);
			if(checkCredentials.isPresent()) {
				
				throw new NotFound("Login Sucessfully!");
			}
			else {
				throw new NotFound("Invalid credantial");
			}
			
		}else {
			throw new NotFound("Password is not match");
		}
	
	}else {
		 throw new NotFound("Email is not match");
    }
	
}
	

}
