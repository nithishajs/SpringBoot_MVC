package com.m.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.m.model.Employee;
import com.m.repo.EmployeeRepo;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepo repo;
	
	public boolean addEmployee(Employee e) {
		    repo.save(e);		
			return true;		
		
	}
	
	public List<Employee> listEmployee(){
		return repo.findAll();
		
	}
	
	public Employee viewEmployee(int id) {
		
		Optional<Employee> op = repo.findById(id);
		
		if(op.isPresent()) {
			return op.get();
		}else {
			return op.orElseThrow();
		}
	}

	public boolean updateEmployee(Employee e) {
		
		boolean status = repo.existsById(e.getId());
		
		if(status!=false) {
			repo.save(e);
			return true;
		}else {
			return false;
		}
		
	}
	
	public boolean deleteEmployee(int id) {
		
		boolean status = repo.existsById(id);
		
		if(status!=false) {
			repo.deleteById(id);
			return true;
		}else {
			return false;
		}
		
	}
	
	public Page<Employee> findPaginated(int pageNo, int pageSize) {
		 Pageable pageable = PageRequest.of(pageNo - 1, pageSize);
		 return repo.findAll(pageable);
		}
	
	
}
